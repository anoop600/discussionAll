package com.mindtree.discussion;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.junit.MockitoJUnitRunner;

import com.mindtree.discussion.dao.ProductDao;
import com.mindtree.discussion.entity.Product;
import com.mindtree.discussion.exception.dao.DaoException;
import com.mindtree.discussion.exception.service.ServiceException;
import com.mindtree.discussion.service.ProductService;
import com.mindtree.discussion.service.serviceImpl.ProductServiceImpl;

@RunWith(MockitoJUnitRunner.Silent.class)
public class MockServiceTest {
	
	static Product p = new Product();

	@Mock
	ProductDao productDao;// = org.mockito.Mockito.mock(ProductDao.class);

	@InjectMocks
	static ProductService pService = new ProductServiceImpl();
	
	@Rule
	public MockitoRule rule = MockitoJUnit.rule();

	@Before
	public void setData() {
		MockitoAnnotations.initMocks(this);
		p.setSlNo(1);
		p.setProduct("Chang");
		p.setPrice(18);
		p.setType("Beverages");

	}

	@Test
	public void test() throws ServiceException, DaoException {
		
			when(productDao.read("Chang")).thenReturn(p);
			assertEquals("Beverages", productDao.read("Chang").getType());
			
	}
}
