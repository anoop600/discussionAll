package com.mindtree.discussion;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ InsertTest.class, GetTest.class })
public class TestSuiteClass {

}
