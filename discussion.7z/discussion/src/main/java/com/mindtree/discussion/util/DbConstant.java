package com.mindtree.discussion.util;

public interface DbConstant {
	String url = "jdbc:mysql://localhost:3306/productdb";
	String user = "root";
	String password = "Welcome123";
}
